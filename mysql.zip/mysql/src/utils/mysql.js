/**
 * 封装mysql数据库操作方法
 */
const mysql = require('mysql');

let pool = mysql.createPool({
    host:'localhost',
    user:'root',
    password: 'root',
    database:'user',
    multipleStatements: true
});


function query(sql){
    return new Promise((resolve , reject)=>{
        pool.query(sql,(error,results,fields)=>{
            if(error){
                reject(error);
            }
            resolve(results);
        })
    })
}

module.exports = query;