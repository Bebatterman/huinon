const express = require('express');
const router  = express.Router();
const query   = require('../utils/mysql');


router.get('/',async (req,res)=>{
    let sql =`select * from user`;

    const result =  await query(sql);
    res.send(result);
})

router.delete('/:id',async (req,res)=>{
    const {id} = req.params;
    let sql = `delete from user where id=${id}`;
    try {
        const result = await query(sql);
        res.send(result)
    }catch(err){
       res.send('删除失败')
    }
})

module.exports = router;